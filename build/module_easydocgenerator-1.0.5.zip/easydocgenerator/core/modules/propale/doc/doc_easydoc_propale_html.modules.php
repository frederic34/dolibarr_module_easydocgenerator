<?php
/* Copyright (C) 2010-2012 	Laurent Destailleur <eldy@users.sourceforge.net>
 * Copyright (C) 2012		Juanjo Menent		<jmenent@2byte.es>
 * Copyright (C) 2014		Marcos García		<marcosgdf@gmail.com>
 * Copyright (C) 2016		Charlie Benke		<charlie@patas-monkey.com>
 * Copyright (C) 2018-2021  Philippe Grand      <philippe.grand@atoo-net.com>
 * Copyright (C) 2018-2024  Frédéric France     <frederic.france@free.fr>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 * or see https://www.gnu.org/
 */

/**
 *	\file       htdocs/core/modules/propal/doc/doc_easydoc_propal_html.modules.php
 *	\ingroup    propal
 *	\brief      File of class to build PDF documents for propales
 */

require_once DOL_DOCUMENT_ROOT . '/core/modules/propale/modules_propale.php';
require_once DOL_DOCUMENT_ROOT . '/product/class/product.class.php';
require_once DOL_DOCUMENT_ROOT . '/categories/class/categorie.class.php';
require_once DOL_DOCUMENT_ROOT . '/contact/class/contact.class.php';
require_once DOL_DOCUMENT_ROOT . '/core/lib/company.lib.php';
require_once DOL_DOCUMENT_ROOT . '/core/lib/functions2.lib.php';
require_once DOL_DOCUMENT_ROOT . '/core/lib/files.lib.php';
require_once DOL_DOCUMENT_ROOT . '/core/lib/doc.lib.php';
require_once DOL_DOCUMENT_ROOT . '/core/lib/pdf.lib.php';
dol_include_once('/easydocgenerator/lib/easydocgenerator.lib.php');
dol_include_once('/easydocgenerator/class/EasyDocHtmlTrait.php');

// phpcs:disable
/**
 *	Class to build documents using HTML templates
 */
class doc_easydoc_propale_html extends ModelePDFPropales
{
	// phpcs:enable
	use EasyDocHtmlTrait;

	/** @var string Dolibarr version of the loaded document */
	public $version = 'dolibarr';

	/**
	 * @param DoliDB $db Database handler
	 */
	public function __construct($db)
	{
		global $langs, $mysoc;

		$langs->loadLangs(['main', 'companies', 'easydocgenerator@easydocgenerator']);

		$this->db = $db;
		$this->name = 'Easydoc templates';
		$this->description = $langs->trans('DocumentModelEasydocgeneratorTemplate');
		$this->scandir = 'PROPALE_ADDON_EASYDOC_TEMPLATES_PATH';
		$this->templateFileSection = 'propales';
		$this->update_main_doc_field = 1;

		$this->type = 'pdf';
		$this->page_largeur = 210;
		$this->page_hauteur = 297;
		$this->format = [$this->page_largeur, $this->page_hauteur];
		$this->marge_gauche = getDolGlobalInt('EASYDOC_PDF_MARGIN_LEFT', 10);
		$this->marge_droite = getDolGlobalInt('EASYDOC_PDF_MARGIN_RIGHT', 10);
		$this->marge_haute = getDolGlobalInt('EASYDOC_PDF_MARGIN_TOP', 48);
		$this->marge_basse = getDolGlobalInt('EASYDOC_PDF_MARGIN_BOTTOM', 25);

		$this->option_logo = 1;
		$this->option_tva = 0;
		$this->option_modereg = 0;
		$this->option_condreg = 0;
		$this->option_multilang = 1;
		$this->option_escompte = 0;
		$this->option_credit_note = 0;
		$this->option_freetext = 1;
		$this->option_draft_watermark = 0;

		$this->emetteur = $mysoc;
		if (!$this->emetteur->country_code) {
			$this->emetteur->country_code = substr($langs->defaultlang, -2);
		}
	}

	// phpcs:disable
	/**
	 *  Function to build a document on disk using the generic odt module.
	 *
	 *	@param		Propal		$object				Object source to build document
	 *	@param		Translate	$outputlangs		Lang output object
	 * 	@param		string		$srctemplatepath	Full path of source filename for generator using a template file
	 *  @param		int			$hidedetails		Do not show line details
	 *  @param		int			$hidedesc			Do not show desc
	 *  @param		int			$hideref			Do not show ref
	 *	@return		int         					1 if OK, <=0 if KO
	 */
	public function write_file($object, $outputlangs, $srctemplatepath = '', $hidedetails = 0, $hidedesc = 0, $hideref = 0)
	{
		// phpcs:enable
		global $action, $conf, $hookmanager, $langs, $mysoc, $user, $outputlangsbis;

		if (empty($srctemplatepath)) {
			dol_syslog('doc_easydoc_propale_html::write_file parameter srctemplatepath empty', LOG_WARNING);
			return -1;
		}

		$object->fetch_thirdparty();

		if (!is_object($outputlangs)) {
			$outputlangs = $langs;
		}
		$languages = ['main', 'dict', 'companies', 'propal', 'bills', 'products', 'orders', 'deliveries', 'banks', 'easydocgenerator@easydocgenerator'];
		$outputlangs->loadLangs($languages);

		$outputlangsbis = null;
		if (getDolGlobalString('PDF_USE_ALSO_LANGUAGE_CODE') && $outputlangs->defaultlang != getDolGlobalString('PDF_USE_ALSO_LANGUAGE_CODE')) {
			$outputlangsbis = new Translate('', $conf);
			$outputlangsbis->setDefaultLang(getDolGlobalString('PDF_USE_ALSO_LANGUAGE_CODE'));
			$outputlangsbis->loadLangs($languages);
		}

		$linkedObjects = pdf_getLinkedObjects($object, $outputlangs);
		$sav_charset_output = $outputlangs->charset_output;
		$outputlangs->charset_output = 'UTF-8';
		if (getDolGlobalInt('MAIN_USE_FPDF')) {
			$outputlangs->charset_output = 'ISO-8859-1';
		}

		$currency = !empty($object->multicurrency_code) ? $object->multicurrency_code : $conf->currency;

		if (!is_object($hookmanager)) {
			include_once DOL_DOCUMENT_ROOT . '/core/class/hookmanager.class.php';
			$hookmanager = new HookManager($this->db);
		}
		$hookmanager->initHooks(['pdfgeneration']);
		$parameters = ['object' => $object, 'outputlangs' => $outputlangs, 'outputlangsbis' => $outputlangsbis];
		$hookmanager->executeHooks('beforePDFCreation', $parameters, $object, $action);

		$twig = $this->buildTwigEnvironment($srctemplatepath);
		try {
			$template = $twig->load(basename($srctemplatepath));
		} catch (\Twig\Error\SyntaxError $e) {
			$this->errors = $e->getMessage() . ' at line ' . $e->getLine() . ' in file ' . $e->getFile();
			return -1;
		} catch (Exception $e) {
			$this->errors = $e->getMessage();
			return -1;
		}

		$logo = $this->buildLogo();
		$flagImage = $this->buildFlagImage();

		$label_payment_conditions = '';
		if ($object->cond_reglement_code) {
			$label_payment_conditions = ($outputlangs->transnoentities('PaymentCondition' . $object->cond_reglement_code) != 'PaymentCondition' . $object->cond_reglement_code) ? $outputlangs->transnoentities('PaymentCondition' . $object->cond_reglement_code) : $outputlangs->convToOutputCharset($object->cond_reglement_doc ? $object->cond_reglement_doc : $object->cond_reglement_label);
			$label_payment_conditions = str_replace('\n', "\n", $label_payment_conditions);
			if ($object->deposit_percent > 0) {
				$label_payment_conditions = str_replace('__DEPOSIT_PERCENT__', $object->deposit_percent, $label_payment_conditions);
			}
		}

		$usecontact = false;
		$arrayidcontact = $object->getIdContact('external', 'CUSTOMER');
		if (count($arrayidcontact) > 0) {
			$usecontact = true;
			$result = $object->fetch_contact($arrayidcontact[0]);
		}
		$contactobject = null;
		if (!empty($usecontact)) {
			if ($object->contact->socid != $object->thirdparty->id && (!isset($conf->global->MAIN_USE_COMPANY_NAME_OF_CONTACT) || getDolGlobalString('MAIN_USE_COMPANY_NAME_OF_CONTACT'))) {
				$object->contact->fetch_thirdparty();
				$socobject = $object->contact->thirdparty;
				$contactobject = $object->contact;
			} else {
				$socobject = $object->thirdparty;
				$contactobject = $object->contact;
			}
		} else {
			$socobject = $object->thirdparty;
		}

		$substitutionarray = [
			'__FROM_NAME__' => $this->emetteur->name,
			'__FROM_EMAIL__' => $this->emetteur->email,
			'__TOTAL_TTC__' => $object->total_ttc,
			'__TOTAL_HT__' => $object->total_ht,
			'__TOTAL_VAT__' => $object->total_tva,
		];
		complete_substitutions_array($substitutionarray, $langs, $object);
		$substitutionarray = array_merge(getCommonSubstitutionArray($outputlangs, 0, null, $object), $substitutionarray);
		$parameters = ['object' => $object, 'outputlangs' => $outputlangs, 'outputlangsbis' => $outputlangsbis, 'substitutionarray' => &$substitutionarray];
		$hookmanager->executeHooks('ODTSubstitution', $parameters, $this, $action);

		$paramfreetext = 'PROPOSAL_FREE_TEXT';
		$newfreetext = '';
		if (!empty($conf->global->$paramfreetext)) {
			$newfreetext = make_substitutions(getDolGlobalString($paramfreetext), $substitutionarray);
		}

		$substitutions = $this->buildMysocSubstitutions($outputlangs, $flagImage);
		$substitutions = array_merge($substitutions, getEachVarObject($object, $outputlangs, 0));
		$substitutions = array_merge($substitutions, $this->buildThirdpartySubstitutions($object, $outputlangs));

		$typescontact = [
			'external' => ['BILLING', 'SHIPPING', 'SALESREPFOLL', 'SERVICE', 'CUSTOMER'],
			'internal' => ['BILLING', 'SHIPPING', 'SALESREPFOLL', 'SERVICE', 'CUSTOMER'],
		];
		$substitutions = array_merge($substitutions, $this->buildContactsSubstitutions($object, $outputlangs, $typescontact));

		$substitutions = array_merge($substitutions, [
			'logo' => $logo,
			'freetext' => $newfreetext,
			'linkedObjects' => $linkedObjects,
			'footerinfo' => getPdfPagefoot($outputlangs, $paramfreetext, $mysoc, $object),
			'labelpaymentconditions' => $label_payment_conditions,
			'currency' => $currency,
			'currencyinfo' => $outputlangs->trans('AmountInCurrency', $outputlangs->trans('Currency' . $currency)),
		]);

		// Propale: extended lines (categories, photos), recursive=false
		$substitutions = array_merge($substitutions, ['lines' => $this->buildExtendedLinesSubstitutions($object, $outputlangs, false)]);

		$substitutions['parameters'] = ['hidedetails' => $hidedetails, 'hidedesc' => $hidedesc, 'hideref' => $hideref];
		if (getDolGlobalInt('EASYDOCGENERATOR_ENABLE_DEVELOPPER_MODE')) {
			$substitutions['debug'] = '<pre>' . print_r($substitutions, true) . '</pre>';
		}

		try {
			$html = $template->render($substitutions);
		} catch (\Twig\Error\SyntaxError $e) {
			$this->errors = $e->getMessage() . ' at line ' . $e->getLine() . ' in file ' . $e->getFile();
			return -1;
		} catch (Exception $e) {
			$this->errors[] = $e->getMessage();
			return -1;
		}

		$mpdf = new \Mpdf\Mpdf([
			'tempDir' => DOL_DATA_ROOT . '/easydocgenerator/temp',
			'format' => $this->format,
			'margin_left' => getDolGlobalInt('EASYDOC_PDF_MARGIN_LEFT', 10),
			'margin_right' => getDolGlobalInt('EASYDOC_PDF_MARGIN_RIGHT', 10),
			'margin_top' => getDolGlobalInt('EASYDOC_PDF_MARGIN_TOP', 48),
			'margin_bottom' => getDolGlobalInt('EASYDOC_PDF_MARGIN_BOTTOM', 25),
			'margin_header' => getDolGlobalInt('EASYDOC_PDF_MARGIN_HEADER', 10),
			'margin_footer' => getDolGlobalInt('EASYDOC_PDF_MARGIN_FOOTER', 10),
		]);
		$mpdf->SetProtection(['print']);
		$mpdf->SetTitle($outputlangs->convToOutputCharset($object->ref));
		$mpdf->SetCreator('Dolibarr ' . DOL_VERSION);
		$mpdf->SetAuthor($outputlangs->convToOutputCharset($user->getFullName($outputlangs)));
		$mpdf->SetKeyWords($outputlangs->convToOutputCharset($object->ref) . ' ' . $outputlangs->transnoentities('PdfCommercialProposalTitle') . ' ' . $outputlangs->convToOutputCharset($object->thirdparty->name));
		$text = getDolGlobalString('PROPALE_DRAFT_WATERMARK');
		$substitutionarray = pdf_getSubstitutionArray($outputlangs, null, null);
		complete_substitutions_array($substitutionarray, $outputlangs, null);
		$text = make_substitutions($text, $substitutionarray, $outputlangs);
		$mpdf->SetWatermarkText($text);
		$mpdf->showWatermarkText = ($object->status == Propal::STATUS_DRAFT && getDolGlobalString('PROPALE_DRAFT_WATERMARK'));
		$mpdf->watermark_font = 'DejaVuSansCondensed';
		$mpdf->watermarkTextAlpha = 0.1;
		$mpdf->SetDisplayMode('fullpage');
		$mpdf->Bookmark($outputlangs->trans('PdfCommercialProposalTitle'));
		$mpdf->WriteHTML($html);

		// Propale-specific: merge product PDFs when PRODUIT_PDF_MERGE_PROPAL is active
		if (getDolGlobalString('PRODUIT_PDF_MERGE_PROPAL')) {
			require_once DOL_DOCUMENT_ROOT . '/product/class/propalmergepdfproduct.class.php';
			$already_merged = [];
			foreach ($object->lines as $line) {
				if (!empty($line->fk_product) && !(in_array($line->fk_product, $already_merged))) {
					$filetomerge = new Propalmergepdfproduct($this->db);
					if (getDolGlobalInt('MAIN_MULTILANGS')) {
						$filetomerge->fetch_by_product($line->fk_product, $outputlangs->defaultlang);
					} else {
						$filetomerge->fetch_by_product($line->fk_product);
					}
					$already_merged[] = $line->fk_product;
					$product = new Product($this->db);
					$product->fetch($line->fk_product);
					$entity_product_file = ($product->entity != $conf->entity) ? $product->entity : $conf->entity;
					if (count($filetomerge->lines) > 0) {
						foreach ($filetomerge->lines as $linefile) {
							if (!empty($linefile->id) && !empty($linefile->file_name)) {
								if (getDolGlobalInt('PRODUCT_USE_OLD_PATH_FOR_PHOTO')) {
									$filetomerge_dir = isModEnabled('product')
										? $conf->product->multidir_output[$entity_product_file] . '/' . get_exdir($product->id, 2, 0, 0, $product, 'product') . $product->id . '/photos'
										: $conf->service->multidir_output[$entity_product_file] . '/' . get_exdir($product->id, 2, 0, 0, $product, 'product') . $product->id . '/photos';
								} else {
									$filetomerge_dir = isModEnabled('product')
										? $conf->product->multidir_output[$entity_product_file] . '/' . get_exdir(0, 0, 0, 0, $product, 'product')
										: $conf->service->multidir_output[$entity_product_file] . '/' . get_exdir(0, 0, 0, 0, $product, 'product');
								}
								dol_syslog(get_class($this) . ':: upload_dir=' . $filetomerge_dir, LOG_DEBUG);
								$infile = $filetomerge_dir . $linefile->file_name;
								if (file_exists($infile) && is_readable($infile)) {
									try {
										$pagecount = $mpdf->setSourceFile($infile);
										$mpdf->SetHeader();
										$mpdf->Bookmark($linefile->file_name);
										for ($i = 1; $i <= $pagecount; $i++) {
											$tplIdx = $mpdf->importPage($i);
											if ($tplIdx !== false) {
												$s = $mpdf->getTemplatesize($tplIdx);
												$mpdf->AddPage($s['height'] > $s['width'] ? 'P' : 'L');
												$mpdf->useTemplate($tplIdx);
											} else {
												setEventMessages(null, [$infile . ' cannot be added, probably protected PDF'], 'warnings');
											}
										}
									} catch (Exception $e) {
										setEventMessage($langs->trans('EasydoCantAddPdfToDoc', $linefile->file_name), 'errors');
										setEventMessage($e->getMessage(), 'errors');
									}
								}
							}
						}
					}
				}
			}
		}

		return $this->savePdf($mpdf, $object, $outputlangs, $conf->propal->multidir_output[$object->entity], $srctemplatepath);
	}
}
