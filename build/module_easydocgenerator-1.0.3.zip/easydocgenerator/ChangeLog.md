
## v1.0.3 (2024-02-16)

#### :rocket: Enhancement
* [#54](https://github.com/frederic34/dolibarr_module_easydocgenerator/pull/54) add pictures in product template ([@frederic34](https://github.com/frederic34))
* [#52](https://github.com/frederic34/dolibarr_module_easydocgenerator/pull/52) add online sign url in invoice ([@frederic34](https://github.com/frederic34))
* [#50](https://github.com/frederic34/dolibarr_module_easydocgenerator/pull/50) add representatives ([@frederic34](https://github.com/frederic34))

#### Committers: 1
- Frédéric FRANCE ([@frederic34](https://github.com/frederic34))


## v1.0.1 (2024-02-08)

#### :rocket: Enhancement
* [#44](https://github.com/frederic34/dolibarr_module_easydocgenerator/pull/44) add ace editor ([@frederic34](https://github.com/frederic34))
* [#12](https://github.com/frederic34/dolibarr_module_easydocgenerator/pull/12) better use of twig and catch errors ([@frederic34](https://github.com/frederic34))

#### :bug: Bug Fix
* [#39](https://github.com/frederic34/dolibarr_module_easydocgenerator/pull/39) fix template deploy ([@frederic34](https://github.com/frederic34))

#### Committers: 1
- Frédéric FRANCE ([@frederic34](https://github.com/frederic34))


## v1.0.0 (2024-01-28)

#### :rocket: Enhancement
* [#4](https://github.com/frederic34/dolibarr_module_easydocgenerator/pull/4) add propale template ([@frederic34](https://github.com/frederic34))

#### Committers: 1
- Frédéric FRANCE ([@frederic34](https://github.com/frederic34))
