
## Unreleased (2024-02-06)

#### :rocket: Enhancement
* [#12](https://github.com/frederic34/dolibarr_module_easydocgenerator/pull/12) better use of twig and catch errors ([@frederic34](https://github.com/frederic34))

#### Committers: 1
- Frédéric FRANCE ([@frederic34](https://github.com/frederic34))


## v1.0.0 (2024-01-28)

#### :rocket: Enhancement
* [#4](https://github.com/frederic34/dolibarr_module_easydocgenerator/pull/4) add propale template ([@frederic34](https://github.com/frederic34))

#### Committers: 1
- Frédéric FRANCE ([@frederic34](https://github.com/frederic34))
