
## v1.0.0 (2024-01-28)

#### :rocket: Enhancement
* [#4](https://github.com/frederic34/dolibarr_module_easydocgenerator/pull/4) add propale template ([@frederic34](https://github.com/frederic34))

#### Committers: 1
- Frédéric FRANCE ([@frederic34](https://github.com/frederic34))
